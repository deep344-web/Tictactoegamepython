from tkinter import *
from tkinter import messagebox
import random as rd
root=Tk()
root.iconbitmap("Logo.ico")
root.title("Tic Tac Toe")
root.resizable(width=False,height=False)
click=True
count=0  # to check how many moves performed
# total moves =9 , 9 buttons var
b1,b2=StringVar(),StringVar()
b3,b4,b5=StringVar(),StringVar(),StringVar()
b6,b7=StringVar(),StringVar()
b8,b9=StringVar(),StringVar()

#devil= player1,angel=player2
devil=PhotoImage(file="devil.png")
angel=PhotoImage(file="angel.png")
	
def playgame():
	v=o.get()
	r1.grid_forget()
	r2.grid_forget()

	if(v==2):

		#Design Button
		Bt1=Button(root,bg="#ff8533",relief=SUNKEN,width=20,height=10,textvariable=b1,command=lambda:press(1,0,0),borderwidth=6)
		  # Lambda --> No name function it here call the press_P1 funct when button is pushed
		Bt2=Button(root,bg="#ff8533",relief=SUNKEN,width=20,height=10,textvariable=b2,command=lambda:press(2,0,1),borderwidth=6)
		Bt3=Button(root,bg="#ff8533",relief=SUNKEN,width=20,height=10,textvariable=b3,command=lambda:press(3,0,2),borderwidth=6)
		
		Bt4=Button(root,bg="#ffffff",relief=SUNKEN,width=20,height=10,textvariable=b4,command=lambda:press(4,1,0),borderwidth=6)
		Bt5=Button(root,bg="#ffffff",relief=SUNKEN,width=20,height=10,textvariable=b5,command=lambda:press(5,1,1),borderwidth=6)
		Bt6=Button(root,bg="#ffffff",relief=SUNKEN,width=20,height=10,textvariable=b6,command=lambda:press(6,1,2),borderwidth=6)

		Bt7=Button(root,bg="#66ff33",relief=SUNKEN,width=20,height=10,textvariable=b7,command=lambda:press(7,2,0),borderwidth=6)
		Bt8=Button(root,bg="#66ff33",relief=SUNKEN,width=20,height=10,textvariable=b8,command=lambda:press(8,2,1),borderwidth=6)
		Bt9=Button(root,bg="#66ff33",relief=SUNKEN,width=20,height=10,textvariable=b9,command=lambda:press(9,2,2),borderwidth=6)
		
		#Place the button
		Bt1.grid(row=0,column=0)
		Bt2.grid(row=0,column=1)
		Bt3.grid(row=0,column=2)

		Bt4.grid(row=1,column=0)
		Bt5.grid(row=1,column=1)
		Bt6.grid(row=1,column=2)

		Bt7.grid(row=2,column=0)
		Bt8.grid(row=2,column=1)
		Bt9.grid(row=2,column=2)
	elif v==1:
		#Design Button
		Bt1=Button(root,bg="#ff8533",relief=SUNKEN,width=20,height=10,textvariable=b1,command=lambda:press_P1(1,0,0),borderwidth=6)
		  # Lambda --> No name function it here call the press_P1 funct when button is pushed
		Bt2=Button(root,bg="#ff8533",relief=SUNKEN,width=20,height=10,textvariable=b2,command=lambda:press_P1(2,0,1),borderwidth=6)
		Bt3=Button(root,bg="#ff8533",relief=SUNKEN,width=20,height=10,textvariable=b3,command=lambda:press_P1(3,0,2),borderwidth=6)
		
		Bt4=Button(root,bg="#ffffff",relief=SUNKEN,width=20,height=10,textvariable=b4,command=lambda:press_P1(4,1,0),borderwidth=6)
		Bt5=Button(root,bg="#ffffff",relief=SUNKEN,width=20,height=10,textvariable=b5,command=lambda:press_P1(5,1,1),borderwidth=6)
		Bt6=Button(root,bg="#ffffff",relief=SUNKEN,width=20,height=10,textvariable=b6,command=lambda:press_P1(6,1,2),borderwidth=6)

		Bt7=Button(root,bg="#66ff33",relief=SUNKEN,width=20,height=10,textvariable=b7,command=lambda:press_P1(7,2,0),borderwidth=6)
		Bt8=Button(root,bg="#66ff33",relief=SUNKEN,width=20,height=10,textvariable=b8,command=lambda:press_P1(8,2,1),borderwidth=6)
		Bt9=Button(root,bg="#66ff33",relief=SUNKEN,width=20,height=10,textvariable=b9,command=lambda:press_P1(9,2,2),borderwidth=6)
		
		#Place the button
		Bt1.grid(row=0,column=0)
		Bt2.grid(row=0,column=1)
		Bt3.grid(row=0,column=2)

		Bt4.grid(row=1,column=0)
		Bt5.grid(row=1,column=1)
		Bt6.grid(row=1,column=2)

		Bt7.grid(row=2,column=0)
		Bt8.grid(row=2,column=1)
		Bt9.grid(row=2,column=2)
o=IntVar()

r1=Radiobutton(root,text="1 Player",variable=o,value=1,command=playgame,font=("Arial Black",20,"bold"),fg="red",bg="#00b300")
r1.grid(row=1,column=0)
r2=Radiobutton(root,text="2 Players",variable=o,value=2,command=playgame,font=("Arial Black",20,"bold"),fg="red",bg="#00b300")
r2.grid(row=1,column=1)

user=[]
own=[]
wincobo=[(0,1,2),(3,4,5),(6,7,8),(0,4,8),(2,4,6),(1,4,7),(2,5,8)]
bts=[b1,b2,b3,b4,b5,b6,b7,b8,b9]
bts_cor=[(0,0),(0,1),(0,2),(1,0),(1,1),(1,2),(2,0),(2,1),(2,2)]
def comp():
	global wincobo,count,bts,bts_cor,user,own
	empty=[]
	
	
	c=0
	for i in bts:
		#print(i.get())
		if i.get()=="":

			empty.append(c)

		elif i.get()=="X":
		#	print(c)
			own.append(c)
		elif i.get()=="O":
			user.append(c)
		c+=1
	#print(user)
	tmp1=[]
	tmp2=[]
	for i in empty:
		tmp1.append(bts[i])
		tmp2.append(bts_cor[i])
	bts=tmp1
	bts_cor=tmp2
	moves=[]
	flag=0
	move=rd.randint(0,len(empty)-1)
#	print(empty,bts_cor)
	#print("Own : ",own)
	tmp=0
	for  i in wincobo:
		if(i[0]  in empty and i[1] in empty and i[2]  in empty )or (i[0] in own and i[1] in own and i[2] in own):
			if(i[0] in own):
				if(i[1] in own):
					tmp=i[2]
					break
				elif(i[2] in own):
					tmp=i[1]
					break
			elif(i[1] in own):
				if(i[0] in own):
					tmp=i[2]
					break
				elif(i[2] in own):
					tmp=i[0]
					break
			elif(i[2] in own):
				if(i[1] in own):
					tmp=i[0]
					break
				elif(i[0] in own):
					tmp=i[1]
					break

		else:
			continue
		

	else:
		if len(user)>0:
			put=()
			for	i in wincobo:
				flag=0
				c=0
				for j in i:
					if j in user:
						c+=1

					else:
						temp=j

						
					if c==2:
						put=i
						flag=1
						break
				if flag:
					moves.append(i)
		if(bool(flag)):
			move=temp
		elif len(user)==0:
			move=4
		else:
			move=rd.randint(0,len(empty)-1)

	
	row,col=bts_cor[move]
	Label(root,image=devil).grid(row=row,column=col)
	bts[move].set("X")
	count+=1


def chwin():
	if count<=9:
		#Case 1 : Combi with =B1
		if(b1.get()==b2.get()==b3.get()=='X'):
			messagebox.showinfo("Game Result","Devil Wins")
			clear()
		elif(b1.get()==b2.get()==b3.get()=='O'):
			messagebox.showinfo("Game Result","Angel Wins")
			clear()
		elif(b1.get()==b5.get()==b9.get()=='O'):
			messagebox.showinfo("Game Result","Angel Wins")
			clear()
		elif(b1.get()==b5.get()==b9.get()=='X'):
			messagebox.showinfo("Game Result","Devil Wins")
			clear()
		elif(b1.get()==b4.get()==b7.get()=='O'):
			messagebox.showinfo("Game Result","Angel Wins")
			clear()
		elif(b1.get()==b4.get()==b7.get()=='X'):
			messagebox.showinfo("Game Result","Devil Wins")
			clear()
		elif(b1.get()==b4.get()==b7.get()=='O'):
			messagebox.showinfo("Game Result","Angel Wins")
			clear()
		#Case2 :  Combi with B2
		elif(b2.get()==b5.get()==b8.get()=='X'):
			messagebox.showinfo("Game Result","Devil Wins")
			clear()
		elif(b2.get()==b5.get()==b8.get()=='O'):
			messagebox.showinfo("Game Result","Angel Wins")
			clear()
		#Case3: Combi with B3:
		elif(b3.get()==b6.get()==b9.get()=='X'):
			messagebox.showinfo("Game Result","Devil Wins")
			clear()
		elif(b3.get()==b6.get()==b9.get()=='O'):
			messagebox.showinfo("Game Result","Angel Wins")
			clear()
		elif(b3.get()==b5.get()==b7.get()=='X'):
			messagebox.showinfo("Game Result","Devil Wins")
			clear()
		elif(b3.get()==b5.get()==b7.get()=='O'):
			messagebox.showinfo("Game Result","Angel Wins")
			clear()
		#Case4: When ur are at B4
		elif(b4.get()==b5.get()==b6.get()=='X'):
			messagebox.showinfo("Game Result","Devil Wins")
			clear()
		elif(b4.get()==b5.get()==b6.get()=='O'):
			messagebox.showinfo("Game Result","Angel Wins")
			clear()
		#Case5: When ur at B7
		elif(b7.get()==b8.get()==b9.get()=='X'):
			messagebox.showinfo("Game Result","Devil Wins")
			clear()
		elif(b7.get()==b8.get()==b9.get()=='O'):
			messagebox.showinfo("Game Result","Angel Wins")
			clear()
		elif count>=9:
			messagebox.showinfo("Game Result","The Game is Tie Now")
			clear()
def clear():
	global count,click,bts,bts_cor,user
	b1.set("")
	b2.set("")
	b3.set("")
	b4.set("")
	b5.set("")
	b6.set("")
	b7.set("")
	b8.set("")
	b9.set("")
	bts=[b1,b2,b3,b4,b5,b6,b7,b8,b9]
	bts_cor=[(0,0),(0,1),(0,2),(1,0),(1,1),(1,2),(2,0),(2,1),(2,2)]
	user=[]
	count=0
	click=True
	playgame()


def press_P1(btno,row,col):
	global click,count  #use global variables above made
	Label(root,image=angel).grid(row=row,column=col)
	if btno==1:
		b1.set('O')
	elif btno==2:
		b2.set("O")
	elif btno==3:
		b3.set("O")
	elif btno==4:
		b4.set("O")
	elif btno==5:
		b5.set("O")
	elif btno==6:
		b6.set("O")
	elif btno==7:
		b7.set("O")
	elif btno==8:
		b8.set("O")
	elif btno==9:
		b9.set("O")
	count+=1
	chwin()
	comp() # next player turn
	chwin()
	

def press(btno,row,col):
	global click,count  #use global variables above made
	if(click==True):  # player 1  -->1st
		Label(root,image=devil).grid(row=row,column=col)
		if btno==1:
			b1.set('X')
		elif btno==2:
			b2.set("X")
		elif btno==3:
			b3.set("X")
		elif btno==4:
			b4.set("X")
		elif btno==5:
			b5.set("X")
		elif btno==6:
			b6.set("X")
		elif btno==7:
			b7.set("X")
		elif btno==8:
			b8.set("X")
		elif btno==9:
			b9.set("X")
		count+=1
		click=False
		    
	else:   # player 2-->2nd
		Label(root,image=angel).grid(row=row,column=col)
		if btno==1:
			b1.set('O')
		elif btno==2:
			b2.set("O")
		elif btno==3:
			b3.set("O")
		elif btno==4:
			b4.set("O")
		elif btno==5:
			b5.set("O")
		elif btno==6:
			b6.set("O")
		elif btno==7:
			b7.set("O")
		elif btno==8:
			b8.set("O")
		elif btno==9:
			b9.set("O")
		count+=1
		click=True # next player turn
	chwin()


root.mainloop()
